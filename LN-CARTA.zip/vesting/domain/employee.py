class Employee:

    def __init__(self, employee_id, name):
        self.id = employee_id
        self.name = name
